package com.csuwebeng.opendiseaseapp.services;

public interface CovidDataSyncService {
    public void syncCovidData();
}
